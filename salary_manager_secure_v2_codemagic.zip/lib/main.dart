
import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:file_picker/file_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DB.init();
  runApp(const App());
}

String b64(List<int> x) => base64UrlEncode(x);
List<int> unb64(String x) => base64Url.decode(x);
String hashPassword(String password, String salt) {
  var bytes = utf8.encode(password);
  final saltBytes = utf8.encode(salt);
  for (int i = 0; i < 120000; i++) {
    bytes = sha256.convert([...saltBytes, ...bytes]).bytes;
  }
  return b64(bytes);
}
String newSalt() => b64(List<int>.generate(16, (_) => Random.secure().nextInt(256)));
String passwordRecord(String p) {
  final s = newSalt();
  return '$s:${hashPassword(p,s)}';
}
bool verifyPassword(String p, String rec) {
  final a = rec.split(':');
  return a.length == 2 && hashPassword(p,a[0]) == a[1];
}

class DB {
  static late Database db;
  static Future<void> init() async {
    db = await openDatabase(join(await getDatabasesPath(),'salary_secure.db'),
      version: 2,
      onCreate: (d,v) async {
        await d.execute('CREATE TABLE employees(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,rank TEXT,department TEXT,salary REAL NOT NULL,phone TEXT,active INTEGER DEFAULT 1)');
        await d.execute('CREATE TABLE attendance(id INTEGER PRIMARY KEY AUTOINCREMENT,employee_id INTEGER,date TEXT,status TEXT,UNIQUE(employee_id,date))');
        await d.execute('CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,employee_id INTEGER,amount REAL,date TEXT,note TEXT)');
        await d.execute('CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE,password_hash TEXT,role TEXT)');
        await d.insert('users', {'username':'admin','password_hash':passwordRecord('1234'),'role':'admin'});
        await d.insert('users', {'username':'manager','password_hash':passwordRecord('1234'),'role':'manager'});
        await d.insert('users', {'username':'viewer','password_hash':passwordRecord('1234'),'role':'viewer'});
      },
      onUpgrade: (d,old,v) async {
        if (old < 2) {
          // Legacy plaintext password column is intentionally not migrated into
          // a usable plaintext store. Existing legacy users should reset passwords.
          try { await d.execute('ALTER TABLE users ADD COLUMN password_hash TEXT'); } catch (_) {}
        }
      });
  }
  static Future<Map<String,dynamic>?> login(String u,String p) async {
    final x=await db.query('users',where:'username=?',whereArgs:[u],limit:1);
    if(x.isEmpty) return null;
    final row=x.first;
    final h=row['password_hash'];
    if(h is String && verifyPassword(p,h)) return row;
    return null;
  }
  static Future<void> setPassword(int id,String p)=>db.update('users',{'password_hash':passwordRecord(p)},where:'id=?',whereArgs:[id]);
  static Future<List<Map<String,dynamic>>> users()=>db.query('users',orderBy:'username');
  static Future<int> addUser(String u,String p,String role)=>db.insert('users',{'username':u.trim(),'password_hash':passwordRecord(p),'role':role});
  static Future<int> deleteUser(int id)=>db.delete('users',where:'id=?',whereArgs:[id]);
  static Future<List<Map<String,dynamic>>> employees({String q=''})=>db.query('employees',where:q.isEmpty?null:'name LIKE ? OR rank LIKE ? OR department LIKE ?',whereArgs:q.isEmpty?null:['%$q%','%$q%','%$q%'],orderBy:'id DESC');
  static Future<int> addEmployee(Map<String,dynamic>x)=>db.insert('employees',x);
  static Future<int> updateEmployee(int id,Map<String,dynamic>x)=>db.update('employees',x,where:'id=?',whereArgs:[id]);
  static Future<void> deleteEmployee(int id) async {await db.delete('attendance',where:'employee_id=?',whereArgs:[id]);await db.delete('payments',where:'employee_id=?',whereArgs:[id]);await db.delete('employees',where:'id=?',whereArgs:[id]);}
  static Future<List<Map<String,dynamic>>> attendance(String date)=>db.rawQuery('SELECT e.*,COALESCE(a.status,"absent") status FROM employees e LEFT JOIN attendance a ON e.id=a.employee_id AND a.date=? WHERE e.active=1 ORDER BY e.id DESC',[date]);
  static Future<void> setAttendance(int id,String date,String status)=>db.insert('attendance',{'employee_id':id,'date':date,'status':status},conflictAlgorithm:ConflictAlgorithm.replace);
  static Future<double> paid(int id) async {final r=await db.rawQuery('SELECT COALESCE(SUM(amount),0) s FROM payments WHERE employee_id=?',[id]);return (r.first['s'] as num).toDouble();}
  static Future<List<Map<String,dynamic>>> payments(int id)=>db.query('payments',where:'employee_id=?',whereArgs:[id],orderBy:'date DESC,id DESC');
  static Future<void> payment(int id,double amount,String note)=>db.insert('payments',{'employee_id':id,'amount':amount,'date':DateTime.now().toIso8601String(),'note':note});
  static Future<String> backup() async {
    final d={'version':2,'created_at':DateTime.now().toIso8601String(),'employees':await db.query('employees'),'attendance':await db.query('attendance'),'payments':await db.query('payments'),'users':await db.query('users',columns:['id','username','password_hash','role'])};
    return jsonEncode(d);
  }
  static Future<void> restore(String raw) async {
    final d=jsonDecode(raw);
    if(d is! Map || d['version']==null || d['employees'] is! List || d['attendance'] is! List || d['payments'] is! List || d['users'] is! List) throw Exception('ساختار Backup معتبر نیست');
    await db.transaction((tx) async {
      for(final t in ['attendance','payments','employees','users']) await tx.delete(t);
      for(final row in d['employees']) {final m=Map<String,dynamic>.from(row);m.remove('id');await tx.insert('employees',m);}
      for(final row in d['attendance']) {final m=Map<String,dynamic>.from(row);m.remove('id');await tx.insert('attendance',m,conflictAlgorithm:ConflictAlgorithm.replace);}
      for(final row in d['payments']) {final m=Map<String,dynamic>.from(row);m.remove('id');await tx.insert('payments',m);}
      for(final row in d['users']) {final m=Map<String,dynamic>.from(row);m.remove('id');if(m['password_hash'] is String) await tx.insert('users',m);}
    });
  }
}

class Session {
  static Map<String,dynamic>? user;
  static DateTime? last;
  static const idle=Duration(minutes:10);
  static bool valid(){if(user==null||last==null)return false;if(DateTime.now().difference(last!)>idle){logout();return false;}last=DateTime.now();return true;}
  static void touch(){if(user!=null)last=DateTime.now();}
  static void logout(){user=null;last=null;}
}

class App extends StatefulWidget {const App({super.key});State<App>createState()=>_AppState();}
class _AppState extends State<App> with WidgetsBindingObserver {
  @override void initState(){super.initState();WidgetsBinding.instance.addObserver(this);}
  @override void dispose(){WidgetsBinding.instance.removeObserver(this);super.dispose();}
  @override void didChangeAppLifecycleState(AppLifecycleState s){if(s==AppLifecycleState.paused||s==AppLifecycleState.inactive){Session.last=DateTime.now().subtract(Session.idle);}}
  @override Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,title:'مدیریت معاش',theme:ThemeData(useMaterial3:true,colorSchemeSeed:Colors.indigo),home:const Login());
}

class Login extends StatefulWidget{const Login({super.key});State<Login>createState()=>_LoginState();}
class _LoginState extends State<Login>{
  final u=TextEditingController(),p=TextEditingController();bool hide=true,busy=false;int fails=0;DateTime? locked;
  Future<void> go()async{
    if(locked!=null&&DateTime.now().isBefore(locked!)){setState((){});return;}
    if(u.text.trim().isEmpty||p.text.isEmpty)return;
    setState(()=>busy=true);final x=await DB.login(u.text.trim(),p.text);setState(()=>busy=false);
    if(x!=null){fails=0;Session.user=x;Session.touch();if(mounted)Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const Home()));}
    else{fails++;if(fails>=5){locked=DateTime.now().add(const Duration(minutes:2));fails=0;}if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('ورود ناموفق است')));}
  }
  @override Widget build(BuildContext c)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(body:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:430),child:Card(child:Padding(padding:const EdgeInsets.all(24),child:Column(children:[
    const Icon(Icons.lock,size:64),const SizedBox(height:12),const Text('مدیریت معاش کارمندان',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),const SizedBox(height:20),
    TextField(controller:u,decoration:const InputDecoration(labelText:'نام کاربری',prefixIcon:Icon(Icons.person))),
    TextField(controller:p,obscureText:hide,decoration:InputDecoration(labelText:'رمز عبور',prefixIcon:const Icon(Icons.lock),suffixIcon:IconButton(onPressed:()=>setState(()=>hide=!hide),icon:const Icon(Icons.visibility)))),
    const SizedBox(height:20),SizedBox(width:double.infinity,child:FilledButton(onPressed:busy?null:go,child:Text(locked!=null&&DateTime.now().isBefore(locked!)?'قفل موقت':'ورود')))
  ]))))))));
}

class Home extends StatefulWidget{const Home({super.key});State<Home>createState()=>_HomeState();}
class _HomeState extends State<Home>{
  int tab=0;final names=['داشبورد','کارمندان','حاضری','گزارش معاش','تنظیمات'];
  bool edit()=>Session.user!['role']!='viewer';
  @override Widget build(BuildContext c){
    if(!Session.valid())return const Login();
    final pages=[const Dashboard(),Employees(canEdit:edit()),Attendance(canEdit:edit()),const Reports(),Settings(isAdmin:Session.user!['role']=='admin')];
    return GestureDetector(onTap:Session.touch,child:Directionality(textDirection:TextDirection.rtl,child:Scaffold(appBar:AppBar(title:Text(names[tab]),actions:[IconButton(onPressed:(){Session.logout();Navigator.pushReplacement(c,MaterialPageRoute(builder:(_)=>const Login()));},icon:const Icon(Icons.logout))]),body:pages[tab],bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),destinations:const[
      NavigationDestination(icon:Icon(Icons.dashboard),label:'داشبورد'),NavigationDestination(icon:Icon(Icons.people),label:'کارمندان'),NavigationDestination(icon:Icon(Icons.event),label:'حاضری'),NavigationDestination(icon:Icon(Icons.receipt),label:'معاش'),NavigationDestination(icon:Icon(Icons.settings),label:'تنظیمات')]))));
  }
}
class Dashboard extends StatelessWidget{const Dashboard({super.key});@override Widget build(BuildContext c)=>FutureBuilder(future:DB.employees(),builder:(c,s){final e=s.data??[];final total=e.fold<double>(0,(a,x)=>a+(x['salary']as num).toDouble());return ListView(padding:const EdgeInsets.all(16),children:[Card(child:ListTile(title:const Text('کارمندان فعال'),trailing:Text('${e.length}'))),Card(child:ListTile(title:const Text('مجموع معاش ماهانه'),trailing:Text(total.toStringAsFixed(0))))];});}}
class Employees extends StatefulWidget{final bool canEdit;const Employees({super.key,required this.canEdit});State<Employees>createState()=>_EmployeesState();}
class _EmployeesState extends State<Employees>{
 String q='';
 void form([Map<String,dynamic>?e]){final n=TextEditingController(text:e?['name']??''),r=TextEditingController(text:e?['rank']??''),d=TextEditingController(text:e?['department']??''),s=TextEditingController(text:e==null?'':e['salary'].toString()),ph=TextEditingController(text:e?['phone']??'');showDialog(context:context,builder:(_)=>Directionality(textDirection:TextDirection.rtl,child:AlertDialog(title:Text(e==null?'افزودن کارمند':'ویرایش کارمند'),content:SingleChildScrollView(child:Column(children:[TextField(controller:n,decoration:const InputDecoration(labelText:'نام')),TextField(controller:r,decoration:const InputDecoration(labelText:'رتبه')),TextField(controller:d,decoration:const InputDecoration(labelText:'بخش')),TextField(controller:s,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'معاش')),TextField(controller:ph,decoration:const InputDecoration(labelText:'شماره تماس'))])),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('لغو')),FilledButton(onPressed:()async{if(n.text.trim().isEmpty)return;final x={'name':n.text.trim(),'rank':r.text.trim(),'department':d.text.trim(),'salary':double.tryParse(s.text)??0,'phone':ph.text.trim(),'active':1};if(e==null)await DB.addEmployee(x);else await DB.updateEmployee(e['id'],x);if(mounted){Navigator.pop(context);setState((){});}},child:const Text('ذخیره'))])));}
 void pay(Map e){final a=TextEditingController(),n=TextEditingController();showDialog(context:context,builder:(_)=>AlertDialog(title:Text('پرداخت ${e['name']}'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:a,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'مبلغ')),TextField(controller:n,decoration:const InputDecoration(labelText:'یادداشت'))]),actions:[FilledButton(onPressed:()async{final x=double.tryParse(a.text);if(x==null||x<=0)return;await DB.payment(e['id'],x,n.text);if(mounted){Navigator.pop(context);setState((){});}},child:const Text('ثبت'))]));}
 @override Widget build(BuildContext c)=>Column(children:[Padding(padding:const EdgeInsets.all(10),child:Row(children:[Expanded(child:TextField(onChanged:(x)=>setState(()=>q=x),decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'جستجو',border:OutlineInputBorder()))),if(widget.canEdit)IconButton(onPressed:()=>form(),icon:const Icon(Icons.add_circle))])),Expanded(child:FutureBuilder(future:DB.employees(q:q),builder:(c,s){final es=s.data??[];return ListView.builder(itemCount:es.length,itemBuilder:(c,i){final e=es[i];return Card(child:ListTile(title:Text(e['name']),subtitle:Text('${e['rank']} | ${e['department']}\nمعاش: ${e['salary']}'),isThreeLine:true,trailing:widget.canEdit?PopupMenuButton<String>(onSelected:(v)async{if(v=='edit')form(e);if(v=='pay')pay(e);if(v=='del'){await DB.deleteEmployee(e['id']);setState((){});}},itemBuilder:(_)=>const[PopupMenuItem(value:'edit',child:Text('ویرایش')),PopupMenuItem(value:'pay',child:Text('ثبت پرداخت')),PopupMenuItem(value:'del',child:Text('حذف'))]):null));});}))]);}
}
class Attendance extends StatefulWidget{final bool canEdit;const Attendance({super.key,required this.canEdit});State<Attendance>createState()=>_AttendanceState();}
class _AttendanceState extends State<Attendance>{DateTime date=DateTime.now();@override Widget build(BuildContext c){final ds=DateFormat('yyyy-MM-dd').format(date);return Column(children:[ListTile(title:Text('تاریخ: $ds'),trailing:IconButton(onPressed:()async{final x=await showDatePicker(context:context,initialDate:date,firstDate:DateTime(2020),lastDate:DateTime(2100));if(x!=null)setState(()=>date=x);},icon:const Icon(Icons.calendar_month))),Expanded(child:FutureBuilder(future:DB.attendance(ds),builder:(c,s){final es=s.data??[];return ListView(children:es.map((e){final p=e['status']=='present';return SwitchListTile(value:p,onChanged:widget.canEdit?(v)async{await DB.setAttendance(e['id'],ds,v?'present':'absent');setState((){});}:null,title:Text(e['name']),subtitle:Text(e['rank']??''),secondary:Icon(p?Icons.check:Icons.close));}).toList());}))]);}}
class Reports extends StatelessWidget{const Reports({super.key});@override Widget build(BuildContext c)=>FutureBuilder(future:DB.employees(),builder:(c,s){final es=s.data??[];return ListView(padding:const EdgeInsets.all(12),children:es.map((e)=>FutureBuilder(future:DB.paid(e['id']),builder:(c,p){final paid=p.data??0;final sal=(e['salary']as num).toDouble();return Card(child:ListTile(title:Text(e['name']),subtitle:Text('معاش: ${sal.toStringAsFixed(0)} | پرداخت: ${paid.toStringAsFixed(0)} | باقی‌مانده: ${(sal-paid).clamp(0,sal).toStringAsFixed(0)}')));})).toList());});}}
class Settings extends StatelessWidget{final bool isAdmin;const Settings({super.key,required this.isAdmin});
 Future<void> change(BuildContext c)async{final p=TextEditingController(),q=TextEditingController();showDialog(context:c,builder:(_)=>AlertDialog(title:const Text('تغییر رمز'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:p,obscureText:true,decoration:const InputDecoration(labelText:'رمز جدید')),TextField(controller:q,obscureText:true,decoration:const InputDecoration(labelText:'تکرار رمز'))]),actions:[FilledButton(onPressed:()async{if(p.text.length<6||p.text!=q.text)return;await DB.setPassword(Session.user!['id'],p.text);if(c.mounted)Navigator.pop(c);},child:const Text('ذخیره'))]));}
 Future<void> backup()async{final raw=await DB.backup();final dir=await getTemporaryDirectory();final f=File('${dir.path}/salary_backup_${DateFormat('yyyyMMdd_HHmmss').format(DateTime.now())}.json');await f.writeAsString(raw);await Share.shareXFiles([XFile(f.path)],text:'Backup مدیریت معاش');}
 Future<void> restore(BuildContext c)async{final r=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['json']);if(r?.files.single.path==null)return;final ok=await showDialog<bool>(context:c,builder:(_)=>AlertDialog(title:const Text('هشدار'),content:const Text('بازیابی، اطلاعات فعلی برنامه را جایگزین می‌کند. ادامه می‌دهید؟'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('لغو')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('بله'))]));if(ok!=true)return;try{await DB.restore(await File(r!.files.single.path!).readAsString());if(c.mounted)ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('Backup بازیابی شد')));}catch(e){if(c.mounted)ScaffoldMessenger.of(c).showSnackBar(SnackBar(content:Text('Backup نامعتبر: $e')));}}
 @override Widget build(BuildContext c)=>ListView(children:[ListTile(title:Text('کاربر: ${Session.user!['username']}'),subtitle:Text('سطح: ${Session.user!['role']}')),ListTile(leading:const Icon(Icons.lock_reset),title:const Text('تغییر رمز'),onTap:()=>change(c)),ListTile(leading:const Icon(Icons.backup),title:const Text('Backup'),onTap:backup),ListTile(leading:const Icon(Icons.restore),title:const Text('Restore'),onTap:()=>restore(c)),if(isAdmin)ListTile(leading:const Icon(Icons.manage_accounts),title:const Text('مدیریت کاربران'),onTap:()=>showDialog(context:c,builder:(_)=>const UserManager()))]);}}
class UserManager extends StatefulWidget{const UserManager({super.key});State<UserManager>createState()=>_UserManagerState();}
class _UserManagerState extends State<UserManager>{
 void add(){final u=TextEditingController(),p=TextEditingController();String role='viewer';showDialog(context:context,builder:(_)=>StatefulBuilder(builder:(c,set)=>AlertDialog(title:const Text('کاربر جدید'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:u,decoration:const InputDecoration(labelText:'نام کاربری')),TextField(controller:p,obscureText:true,decoration:const InputDecoration(labelText:'رمز (حداقل 6 رقم)')),DropdownButton<String>(value:role,onChanged:(x)=>set(()=>role=x!),items:const[DropdownMenuItem(value:'admin',child:Text('Admin')),DropdownMenuItem(value:'manager',child:Text('Manager')),DropdownMenuItem(value:'viewer',child:Text('Viewer'))])]),actions:[FilledButton(onPressed:()async{if(u.text.trim().isEmpty||p.text.length<6)return;try{await DB.addUser(u.text,p.text,role);if(mounted){Navigator.pop(context);setState((){});}}catch(_){}} ,child:const Text('ذخیره'))])));}
 @override Widget build(BuildContext c)=>AlertDialog(title:const Text('مدیریت کاربران'),content:SizedBox(width:500,child:FutureBuilder(future:DB.users(),builder:(c,s){final us=s.data??[];return ListView(shrinkWrap:true,children:us.map((x)=>ListTile(title:Text(x['username']),subtitle:Text(x['role']),trailing:x['username']=='admin'?null:IconButton(onPressed:()async{await DB.deleteUser(x['id']);setState((){});},icon:const Icon(Icons.delete)))).toList());})),actions:[TextButton(onPressed:add,child:const Text('افزودن')),TextButton(onPressed:()=>Navigator.pop(c),child:const Text('بستن'))]);}
}
