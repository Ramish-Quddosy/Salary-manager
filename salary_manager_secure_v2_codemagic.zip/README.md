# Salary Manager Secure v2

Security-focused Flutter employee salary manager.

## Security improvements
- Passwords are stored as salted PBKDF2-derived hashes, not plaintext.
- Per-user roles: Admin / Manager / Viewer.
- Login attempt throttling / temporary lockout.
- Session timeout after inactivity.
- Auto-lock when app returns from background.
- Sensitive salary screens require an active authenticated session.
- Admin-only user management.
- Viewer is read-only.
- Manager cannot manage users or change other users' permissions.
- Backup includes no plaintext passwords.
- Restore validates backup structure and requires confirmation.
- Local-only SQLite storage.

## Important
The default first-run account is:
Username: admin
Password: 1234

Change it immediately after first login.

For a production deployment, add Android Keystore-backed encryption (e.g. SQLCipher), biometric unlock, encrypted backups, audit logs, and signed/versioned backups before storing highly sensitive payroll data.

## Build
flutter pub get
flutter build apk --release
